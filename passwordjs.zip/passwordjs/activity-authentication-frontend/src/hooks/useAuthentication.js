export function UseAuthentication() {
  async function login(username, password) {
    const res = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username, password }),
    });

    if (!res.ok) throw new Error('Login failed');
    return await res.json();
  }

  async function logout() {
    await fetch('http://localhost:3000/logout', {
      method: 'POST',
      credentials: 'include',
    });
  }

  return { login, logout };
}
